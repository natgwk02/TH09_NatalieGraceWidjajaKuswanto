﻿namespace TH09_Natalie_Grace_Widjaja_Kuswanto
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.topWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tShirtsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shirtsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bottomWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.longPantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accessoriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shoesToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.jewelleriesToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.othersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dgv1 = new System.Windows.Forms.DataGridView();
            this.lb_subtotal = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tb_subtotal = new System.Windows.Forms.TextBox();
            this.tb_total = new System.Windows.Forms.TextBox();
            this.panel_tshirt = new System.Windows.Forms.Panel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btn_addtocart1 = new System.Windows.Forms.Button();
            this.btn_addtocart2 = new System.Windows.Forms.Button();
            this.btn_addtocart3 = new System.Windows.Forms.Button();
            this.panel_shirt = new System.Windows.Forms.Panel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.lb_harga3 = new System.Windows.Forms.Label();
            this.lb_harga2 = new System.Windows.Forms.Label();
            this.lb_harga1 = new System.Windows.Forms.Label();
            this.lb_nama3 = new System.Windows.Forms.Label();
            this.lb_nama2 = new System.Windows.Forms.Label();
            this.lb_nama1 = new System.Windows.Forms.Label();
            this.panel_pants = new System.Windows.Forms.Panel();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.panel_jewelleries = new System.Windows.Forms.Panel();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.panel_shoes = new System.Windows.Forms.Panel();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.pictureBox18 = new System.Windows.Forms.PictureBox();
            this.panel_longpants = new System.Windows.Forms.Panel();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.panel_others = new System.Windows.Forms.Panel();
            this.tb_itemprice = new System.Windows.Forms.TextBox();
            this.tb_itemname = new System.Windows.Forms.TextBox();
            this.btn_addtocart = new System.Windows.Forms.Button();
            this.btn_upload = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pb_others = new System.Windows.Forms.PictureBox();
            this.btn_deletecart = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv1)).BeginInit();
            this.panel_tshirt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel_shirt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.panel_pants.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            this.panel_jewelleries.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            this.panel_shoes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).BeginInit();
            this.panel_longpants.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            this.panel_others.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_others)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.topWearToolStripMenuItem,
            this.bottomWearToolStripMenuItem,
            this.accessoriesToolStripMenuItem,
            this.othersToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(915, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // topWearToolStripMenuItem
            // 
            this.topWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tShirtsToolStripMenuItem,
            this.shirtsToolStripMenuItem});
            this.topWearToolStripMenuItem.Name = "topWearToolStripMenuItem";
            this.topWearToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.topWearToolStripMenuItem.Text = "Top Wear";
            // 
            // tShirtsToolStripMenuItem
            // 
            this.tShirtsToolStripMenuItem.Name = "tShirtsToolStripMenuItem";
            this.tShirtsToolStripMenuItem.Size = new System.Drawing.Size(114, 22);
            this.tShirtsToolStripMenuItem.Text = "T-Shirts";
            this.tShirtsToolStripMenuItem.Click += new System.EventHandler(this.tShirtsToolStripMenuItem_Click);
            // 
            // shirtsToolStripMenuItem
            // 
            this.shirtsToolStripMenuItem.Name = "shirtsToolStripMenuItem";
            this.shirtsToolStripMenuItem.Size = new System.Drawing.Size(114, 22);
            this.shirtsToolStripMenuItem.Text = "Shirts";
            this.shirtsToolStripMenuItem.Click += new System.EventHandler(this.shirtsToolStripMenuItem_Click);
            // 
            // bottomWearToolStripMenuItem
            // 
            this.bottomWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.longPantsToolStripMenuItem,
            this.pantsToolStripMenuItem});
            this.bottomWearToolStripMenuItem.Name = "bottomWearToolStripMenuItem";
            this.bottomWearToolStripMenuItem.Size = new System.Drawing.Size(89, 20);
            this.bottomWearToolStripMenuItem.Text = "Bottom Wear";
            // 
            // longPantsToolStripMenuItem
            // 
            this.longPantsToolStripMenuItem.Name = "longPantsToolStripMenuItem";
            this.longPantsToolStripMenuItem.Size = new System.Drawing.Size(133, 22);
            this.longPantsToolStripMenuItem.Text = "Long Pants";
            this.longPantsToolStripMenuItem.Click += new System.EventHandler(this.longPantsToolStripMenuItem_Click);
            // 
            // pantsToolStripMenuItem
            // 
            this.pantsToolStripMenuItem.Name = "pantsToolStripMenuItem";
            this.pantsToolStripMenuItem.Size = new System.Drawing.Size(133, 22);
            this.pantsToolStripMenuItem.Text = "Pants";
            this.pantsToolStripMenuItem.Click += new System.EventHandler(this.pantsToolStripMenuItem_Click);
            // 
            // accessoriesToolStripMenuItem
            // 
            this.accessoriesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.shoesToolStripMenuItem1,
            this.jewelleriesToolStripMenuItem1});
            this.accessoriesToolStripMenuItem.Name = "accessoriesToolStripMenuItem";
            this.accessoriesToolStripMenuItem.Size = new System.Drawing.Size(80, 20);
            this.accessoriesToolStripMenuItem.Text = "Accessories";
            // 
            // shoesToolStripMenuItem1
            // 
            this.shoesToolStripMenuItem1.Name = "shoesToolStripMenuItem1";
            this.shoesToolStripMenuItem1.Size = new System.Drawing.Size(129, 22);
            this.shoesToolStripMenuItem1.Text = "Shoes";
            this.shoesToolStripMenuItem1.Click += new System.EventHandler(this.shoesToolStripMenuItem1_Click);
            // 
            // jewelleriesToolStripMenuItem1
            // 
            this.jewelleriesToolStripMenuItem1.Name = "jewelleriesToolStripMenuItem1";
            this.jewelleriesToolStripMenuItem1.Size = new System.Drawing.Size(129, 22);
            this.jewelleriesToolStripMenuItem1.Text = "Jewelleries";
            this.jewelleriesToolStripMenuItem1.Click += new System.EventHandler(this.jewelleriesToolStripMenuItem1_Click);
            // 
            // othersToolStripMenuItem
            // 
            this.othersToolStripMenuItem.Name = "othersToolStripMenuItem";
            this.othersToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.othersToolStripMenuItem.Text = "Others";
            this.othersToolStripMenuItem.Click += new System.EventHandler(this.othersToolStripMenuItem_Click);
            // 
            // dgv1
            // 
            this.dgv1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv1.Location = new System.Drawing.Point(412, 41);
            this.dgv1.Name = "dgv1";
            this.dgv1.Size = new System.Drawing.Size(491, 218);
            this.dgv1.TabIndex = 1;
            this.dgv1.Click += new System.EventHandler(this.dgv1_Click);
            // 
            // lb_subtotal
            // 
            this.lb_subtotal.AutoSize = true;
            this.lb_subtotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_subtotal.Location = new System.Drawing.Point(433, 279);
            this.lb_subtotal.Name = "lb_subtotal";
            this.lb_subtotal.Size = new System.Drawing.Size(66, 13);
            this.lb_subtotal.TabIndex = 2;
            this.lb_subtotal.Text = "Sub-Total:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(459, 306);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Total:";
            // 
            // tb_subtotal
            // 
            this.tb_subtotal.Location = new System.Drawing.Point(500, 276);
            this.tb_subtotal.Name = "tb_subtotal";
            this.tb_subtotal.Size = new System.Drawing.Size(100, 20);
            this.tb_subtotal.TabIndex = 4;
            // 
            // tb_total
            // 
            this.tb_total.Location = new System.Drawing.Point(500, 303);
            this.tb_total.Name = "tb_total";
            this.tb_total.Size = new System.Drawing.Size(100, 20);
            this.tb_total.TabIndex = 5;
            // 
            // panel_tshirt
            // 
            this.panel_tshirt.Controls.Add(this.pictureBox3);
            this.panel_tshirt.Controls.Add(this.pictureBox2);
            this.panel_tshirt.Controls.Add(this.pictureBox1);
            this.panel_tshirt.Location = new System.Drawing.Point(15, 27);
            this.panel_tshirt.Name = "panel_tshirt";
            this.panel_tshirt.Size = new System.Drawing.Size(373, 144);
            this.panel_tshirt.TabIndex = 6;
            this.panel_tshirt.Visible = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::TH09_Natalie_Grace_Widjaja_Kuswanto.Properties.Resources.T_ShirtKerahV;
            this.pictureBox3.Location = new System.Drawing.Point(253, 25);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(104, 100);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::TH09_Natalie_Grace_Widjaja_Kuswanto.Properties.Resources.T_ShirtKerahKotak;
            this.pictureBox2.Location = new System.Drawing.Point(134, 25);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(104, 100);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::TH09_Natalie_Grace_Widjaja_Kuswanto.Properties.Resources.T_ShirtKerahBulat;
            this.pictureBox1.Location = new System.Drawing.Point(15, 25);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(104, 100);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // btn_addtocart1
            // 
            this.btn_addtocart1.Location = new System.Drawing.Point(40, 216);
            this.btn_addtocart1.Name = "btn_addtocart1";
            this.btn_addtocart1.Size = new System.Drawing.Size(69, 20);
            this.btn_addtocart1.TabIndex = 9;
            this.btn_addtocart1.Text = "Add to Cart";
            this.btn_addtocart1.UseVisualStyleBackColor = true;
            this.btn_addtocart1.Visible = false;
            this.btn_addtocart1.Click += new System.EventHandler(this.btn_addtocart1_Click);
            // 
            // btn_addtocart2
            // 
            this.btn_addtocart2.Location = new System.Drawing.Point(164, 216);
            this.btn_addtocart2.Name = "btn_addtocart2";
            this.btn_addtocart2.Size = new System.Drawing.Size(69, 20);
            this.btn_addtocart2.TabIndex = 10;
            this.btn_addtocart2.Text = "Add to Cart";
            this.btn_addtocart2.UseVisualStyleBackColor = true;
            this.btn_addtocart2.Visible = false;
            this.btn_addtocart2.Click += new System.EventHandler(this.btn_addtocart2_Click);
            // 
            // btn_addtocart3
            // 
            this.btn_addtocart3.Location = new System.Drawing.Point(293, 216);
            this.btn_addtocart3.Name = "btn_addtocart3";
            this.btn_addtocart3.Size = new System.Drawing.Size(69, 20);
            this.btn_addtocart3.TabIndex = 11;
            this.btn_addtocart3.Text = "Add to Cart";
            this.btn_addtocart3.UseVisualStyleBackColor = true;
            this.btn_addtocart3.Visible = false;
            this.btn_addtocart3.Click += new System.EventHandler(this.btn_addtocart3_Click);
            // 
            // panel_shirt
            // 
            this.panel_shirt.Controls.Add(this.pictureBox4);
            this.panel_shirt.Controls.Add(this.pictureBox5);
            this.panel_shirt.Controls.Add(this.pictureBox6);
            this.panel_shirt.Location = new System.Drawing.Point(9, 33);
            this.panel_shirt.Name = "panel_shirt";
            this.panel_shirt.Size = new System.Drawing.Size(373, 141);
            this.panel_shirt.TabIndex = 12;
            this.panel_shirt.Visible = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::TH09_Natalie_Grace_Widjaja_Kuswanto.Properties.Resources.ShirtWhite;
            this.pictureBox4.Location = new System.Drawing.Point(253, 25);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(104, 100);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 2;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::TH09_Natalie_Grace_Widjaja_Kuswanto.Properties.Resources.ShirtRumah;
            this.pictureBox5.Location = new System.Drawing.Point(134, 25);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(104, 100);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 1;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::TH09_Natalie_Grace_Widjaja_Kuswanto.Properties.Resources.ShirtPolo;
            this.pictureBox6.Location = new System.Drawing.Point(15, 25);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(104, 100);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 0;
            this.pictureBox6.TabStop = false;
            // 
            // lb_harga3
            // 
            this.lb_harga3.AutoSize = true;
            this.lb_harga3.Location = new System.Drawing.Point(283, 191);
            this.lb_harga3.Name = "lb_harga3";
            this.lb_harga3.Size = new System.Drawing.Size(72, 13);
            this.lb_harga3.TabIndex = 18;
            this.lb_harga3.Text = "Rp. 170.000,-";
            this.lb_harga3.Visible = false;
            // 
            // lb_harga2
            // 
            this.lb_harga2.AutoSize = true;
            this.lb_harga2.Location = new System.Drawing.Point(152, 191);
            this.lb_harga2.Name = "lb_harga2";
            this.lb_harga2.Size = new System.Drawing.Size(72, 13);
            this.lb_harga2.TabIndex = 17;
            this.lb_harga2.Text = "Rp. 150.000,-";
            this.lb_harga2.Visible = false;
            // 
            // lb_harga1
            // 
            this.lb_harga1.AutoSize = true;
            this.lb_harga1.Location = new System.Drawing.Point(37, 191);
            this.lb_harga1.Name = "lb_harga1";
            this.lb_harga1.Size = new System.Drawing.Size(72, 13);
            this.lb_harga1.TabIndex = 16;
            this.lb_harga1.Text = "Rp. 120.000,-";
            this.lb_harga1.Visible = false;
            // 
            // lb_nama3
            // 
            this.lb_nama3.AutoSize = true;
            this.lb_nama3.Location = new System.Drawing.Point(283, 177);
            this.lb_nama3.Name = "lb_nama3";
            this.lb_nama3.Size = new System.Drawing.Size(42, 13);
            this.lb_nama3.TabIndex = 15;
            this.lb_nama3.Text = "Label 3";
            this.lb_nama3.Visible = false;
            // 
            // lb_nama2
            // 
            this.lb_nama2.AutoSize = true;
            this.lb_nama2.Location = new System.Drawing.Point(152, 177);
            this.lb_nama2.Name = "lb_nama2";
            this.lb_nama2.Size = new System.Drawing.Size(42, 13);
            this.lb_nama2.TabIndex = 14;
            this.lb_nama2.Text = "Label 2";
            this.lb_nama2.Visible = false;
            // 
            // lb_nama1
            // 
            this.lb_nama1.AutoSize = true;
            this.lb_nama1.Location = new System.Drawing.Point(37, 177);
            this.lb_nama1.Name = "lb_nama1";
            this.lb_nama1.Size = new System.Drawing.Size(42, 13);
            this.lb_nama1.TabIndex = 13;
            this.lb_nama1.Text = "Label 1";
            this.lb_nama1.Visible = false;
            // 
            // panel_pants
            // 
            this.panel_pants.Controls.Add(this.pictureBox7);
            this.panel_pants.Controls.Add(this.pictureBox8);
            this.panel_pants.Controls.Add(this.pictureBox9);
            this.panel_pants.Location = new System.Drawing.Point(12, 27);
            this.panel_pants.Name = "panel_pants";
            this.panel_pants.Size = new System.Drawing.Size(373, 144);
            this.panel_pants.TabIndex = 13;
            this.panel_pants.Visible = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::TH09_Natalie_Grace_Widjaja_Kuswanto.Properties.Resources.PantsRunning;
            this.pictureBox7.Location = new System.Drawing.Point(253, 25);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(104, 100);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 2;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::TH09_Natalie_Grace_Widjaja_Kuswanto.Properties.Resources.PantsJeans;
            this.pictureBox8.Location = new System.Drawing.Point(134, 25);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(104, 100);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 1;
            this.pictureBox8.TabStop = false;
            // 
            // panel_jewelleries
            // 
            this.panel_jewelleries.Controls.Add(this.pictureBox13);
            this.panel_jewelleries.Controls.Add(this.pictureBox14);
            this.panel_jewelleries.Controls.Add(this.pictureBox15);
            this.panel_jewelleries.Location = new System.Drawing.Point(15, 27);
            this.panel_jewelleries.Name = "panel_jewelleries";
            this.panel_jewelleries.Size = new System.Drawing.Size(373, 144);
            this.panel_jewelleries.TabIndex = 14;
            this.panel_jewelleries.Visible = false;
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = global::TH09_Natalie_Grace_Widjaja_Kuswanto.Properties.Resources.JewelleriesRing;
            this.pictureBox13.Location = new System.Drawing.Point(253, 25);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(104, 100);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox13.TabIndex = 2;
            this.pictureBox13.TabStop = false;
            // 
            // pictureBox14
            // 
            this.pictureBox14.Image = global::TH09_Natalie_Grace_Widjaja_Kuswanto.Properties.Resources.JewelleriesNecklace;
            this.pictureBox14.Location = new System.Drawing.Point(134, 25);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(104, 100);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox14.TabIndex = 1;
            this.pictureBox14.TabStop = false;
            // 
            // pictureBox15
            // 
            this.pictureBox15.Image = global::TH09_Natalie_Grace_Widjaja_Kuswanto.Properties.Resources.JewelleriesBracelet;
            this.pictureBox15.Location = new System.Drawing.Point(15, 25);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(104, 100);
            this.pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox15.TabIndex = 0;
            this.pictureBox15.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::TH09_Natalie_Grace_Widjaja_Kuswanto.Properties.Resources.PantsJogging;
            this.pictureBox9.Location = new System.Drawing.Point(15, 25);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(104, 100);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 0;
            this.pictureBox9.TabStop = false;
            // 
            // panel_shoes
            // 
            this.panel_shoes.Controls.Add(this.pictureBox16);
            this.panel_shoes.Controls.Add(this.pictureBox17);
            this.panel_shoes.Controls.Add(this.pictureBox18);
            this.panel_shoes.Location = new System.Drawing.Point(9, 30);
            this.panel_shoes.Name = "panel_shoes";
            this.panel_shoes.Size = new System.Drawing.Size(373, 144);
            this.panel_shoes.TabIndex = 20;
            this.panel_shoes.Visible = false;
            // 
            // pictureBox16
            // 
            this.pictureBox16.Image = global::TH09_Natalie_Grace_Widjaja_Kuswanto.Properties.Resources.ShoesPuma;
            this.pictureBox16.Location = new System.Drawing.Point(253, 25);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(104, 100);
            this.pictureBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox16.TabIndex = 2;
            this.pictureBox16.TabStop = false;
            // 
            // pictureBox17
            // 
            this.pictureBox17.Image = global::TH09_Natalie_Grace_Widjaja_Kuswanto.Properties.Resources.ShoesNike;
            this.pictureBox17.Location = new System.Drawing.Point(134, 25);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(104, 100);
            this.pictureBox17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox17.TabIndex = 1;
            this.pictureBox17.TabStop = false;
            // 
            // pictureBox18
            // 
            this.pictureBox18.Image = global::TH09_Natalie_Grace_Widjaja_Kuswanto.Properties.Resources.ShoesAdidas;
            this.pictureBox18.Location = new System.Drawing.Point(15, 25);
            this.pictureBox18.Name = "pictureBox18";
            this.pictureBox18.Size = new System.Drawing.Size(104, 100);
            this.pictureBox18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox18.TabIndex = 0;
            this.pictureBox18.TabStop = false;
            // 
            // panel_longpants
            // 
            this.panel_longpants.Controls.Add(this.pictureBox10);
            this.panel_longpants.Controls.Add(this.pictureBox11);
            this.panel_longpants.Controls.Add(this.pictureBox12);
            this.panel_longpants.Location = new System.Drawing.Point(6, 30);
            this.panel_longpants.Name = "panel_longpants";
            this.panel_longpants.Size = new System.Drawing.Size(373, 144);
            this.panel_longpants.TabIndex = 19;
            this.panel_longpants.Visible = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = global::TH09_Natalie_Grace_Widjaja_Kuswanto.Properties.Resources.LongPantsJogging;
            this.pictureBox10.Location = new System.Drawing.Point(253, 25);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(104, 100);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 2;
            this.pictureBox10.TabStop = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = global::TH09_Natalie_Grace_Widjaja_Kuswanto.Properties.Resources.LongPantsLegging;
            this.pictureBox11.Location = new System.Drawing.Point(134, 25);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(104, 100);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox11.TabIndex = 1;
            this.pictureBox11.TabStop = false;
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = global::TH09_Natalie_Grace_Widjaja_Kuswanto.Properties.Resources.LongPantsHighWaist;
            this.pictureBox12.Location = new System.Drawing.Point(15, 25);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(104, 100);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox12.TabIndex = 0;
            this.pictureBox12.TabStop = false;
            // 
            // panel_others
            // 
            this.panel_others.Controls.Add(this.tb_itemprice);
            this.panel_others.Controls.Add(this.tb_itemname);
            this.panel_others.Controls.Add(this.btn_addtocart);
            this.panel_others.Controls.Add(this.btn_upload);
            this.panel_others.Controls.Add(this.label4);
            this.panel_others.Controls.Add(this.label3);
            this.panel_others.Controls.Add(this.label1);
            this.panel_others.Controls.Add(this.pb_others);
            this.panel_others.Location = new System.Drawing.Point(9, 27);
            this.panel_others.Name = "panel_others";
            this.panel_others.Size = new System.Drawing.Size(373, 192);
            this.panel_others.TabIndex = 14;
            this.panel_others.Visible = false;
            // 
            // tb_itemprice
            // 
            this.tb_itemprice.Location = new System.Drawing.Point(140, 102);
            this.tb_itemprice.Name = "tb_itemprice";
            this.tb_itemprice.Size = new System.Drawing.Size(100, 20);
            this.tb_itemprice.TabIndex = 7;
            this.tb_itemprice.TextChanged += new System.EventHandler(this.tb_itemprice_TextChanged);
            this.tb_itemprice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_itemprice_KeyPress);
            // 
            // tb_itemname
            // 
            this.tb_itemname.Location = new System.Drawing.Point(140, 62);
            this.tb_itemname.Name = "tb_itemname";
            this.tb_itemname.Size = new System.Drawing.Size(100, 20);
            this.tb_itemname.TabIndex = 6;
            this.tb_itemname.TextChanged += new System.EventHandler(this.tb_itemname_TextChanged);
            // 
            // btn_addtocart
            // 
            this.btn_addtocart.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_addtocart.Location = new System.Drawing.Point(140, 139);
            this.btn_addtocart.Name = "btn_addtocart";
            this.btn_addtocart.Size = new System.Drawing.Size(98, 28);
            this.btn_addtocart.TabIndex = 5;
            this.btn_addtocart.Text = "Add to Cart";
            this.btn_addtocart.UseVisualStyleBackColor = true;
            this.btn_addtocart.Click += new System.EventHandler(this.btn_addtocart_Click);
            // 
            // btn_upload
            // 
            this.btn_upload.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_upload.Location = new System.Drawing.Point(120, 9);
            this.btn_upload.Name = "btn_upload";
            this.btn_upload.Size = new System.Drawing.Size(98, 26);
            this.btn_upload.TabIndex = 4;
            this.btn_upload.Text = "Upload";
            this.btn_upload.UseVisualStyleBackColor = true;
            this.btn_upload.Click += new System.EventHandler(this.btn_upload_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(138, 85);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Item Price:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(138, 41);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Item Name:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(28, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Upload Image";
            // 
            // pb_others
            // 
            this.pb_others.Location = new System.Drawing.Point(20, 41);
            this.pb_others.Name = "pb_others";
            this.pb_others.Size = new System.Drawing.Size(100, 98);
            this.pb_others.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_others.TabIndex = 0;
            this.pb_others.TabStop = false;
            // 
            // btn_deletecart
            // 
            this.btn_deletecart.Location = new System.Drawing.Point(641, 280);
            this.btn_deletecart.Name = "btn_deletecart";
            this.btn_deletecart.Size = new System.Drawing.Size(75, 23);
            this.btn_deletecart.TabIndex = 20;
            this.btn_deletecart.Text = "Delete Cart";
            this.btn_deletecart.UseVisualStyleBackColor = true;
            this.btn_deletecart.Click += new System.EventHandler(this.btn_deletecart_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(915, 481);
            this.Controls.Add(this.btn_deletecart);
            this.Controls.Add(this.panel_others);
            this.Controls.Add(this.panel_jewelleries);
            this.Controls.Add(this.panel_longpants);
            this.Controls.Add(this.panel_shoes);
            this.Controls.Add(this.panel_shirt);
            this.Controls.Add(this.panel_pants);
            this.Controls.Add(this.lb_harga3);
            this.Controls.Add(this.lb_harga2);
            this.Controls.Add(this.lb_harga1);
            this.Controls.Add(this.lb_nama3);
            this.Controls.Add(this.lb_nama2);
            this.Controls.Add(this.lb_nama1);
            this.Controls.Add(this.btn_addtocart3);
            this.Controls.Add(this.btn_addtocart2);
            this.Controls.Add(this.btn_addtocart1);
            this.Controls.Add(this.panel_tshirt);
            this.Controls.Add(this.tb_total);
            this.Controls.Add(this.tb_subtotal);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lb_subtotal);
            this.Controls.Add(this.dgv1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "UNIQME";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv1)).EndInit();
            this.panel_tshirt.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel_shirt.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.panel_pants.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            this.panel_jewelleries.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            this.panel_shoes.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).EndInit();
            this.panel_longpants.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            this.panel_others.ResumeLayout(false);
            this.panel_others.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_others)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem topWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bottomWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accessoriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem othersToolStripMenuItem;
        private System.Windows.Forms.DataGridView dgv1;
        private System.Windows.Forms.Label lb_subtotal;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tb_subtotal;
        private System.Windows.Forms.TextBox tb_total;
        private System.Windows.Forms.ToolStripMenuItem tShirtsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shirtsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem longPantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shoesToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem jewelleriesToolStripMenuItem1;
        private System.Windows.Forms.Panel panel_tshirt;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel_shirt;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Button btn_addtocart3;
        private System.Windows.Forms.Button btn_addtocart2;
        private System.Windows.Forms.Button btn_addtocart1;
        private System.Windows.Forms.Label lb_harga3;
        private System.Windows.Forms.Label lb_harga2;
        private System.Windows.Forms.Label lb_harga1;
        private System.Windows.Forms.Label lb_nama3;
        private System.Windows.Forms.Label lb_nama2;
        private System.Windows.Forms.Label lb_nama1;
        private System.Windows.Forms.Panel panel_pants;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.Panel panel_longpants;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.Panel panel_jewelleries;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.Panel panel_shoes;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.PictureBox pictureBox18;
        private System.Windows.Forms.Panel panel_others;
        private System.Windows.Forms.Button btn_upload;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pb_others;
        private System.Windows.Forms.TextBox tb_itemprice;
        private System.Windows.Forms.TextBox tb_itemname;
        private System.Windows.Forms.Button btn_addtocart;
        private System.Windows.Forms.Button btn_deletecart;
    }
}

