﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.PerformanceData;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH09_Natalie_Grace_Widjaja_Kuswanto
{

    public partial class Form1 : Form
    {
        OpenFileDialog ofd = new OpenFileDialog();
        DataTable shop;
        string tampung = "";
        int hargaproduk1;
        int hargaproduk2;
        int hargaproduk3;
        int baris;

        public Form1()
        {
            InitializeComponent();
            tb_itemprice.KeyPress += tb_itemprice_KeyPress;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            shop = new DataTable();
            shop.Columns.Add("Item Name");
            shop.Columns.Add("Quantity");
            shop.Columns.Add("Price");
            shop.Columns.Add("Total");
            dgv1.DataSource = shop;

        }

        private void defaultpbox()
        {
            panel_tshirt.Visible = false;
            panel_shirt.Visible = false;
            panel_pants.Visible = false;
            panel_longpants.Visible = false;
            panel_shoes.Visible = false;
            panel_jewelleries.Visible = false;
            panel_others.Visible = false;
        }
        private void defaultvisible()
        {
            lb_nama1.Visible = true;
            lb_nama2.Visible = true;
            lb_nama3.Visible = true;
            lb_harga1.Visible = true;
            lb_harga2.Visible = true;
            lb_harga3.Visible = true;
            btn_addtocart1.Visible = true;
            btn_addtocart2.Visible = true;
            btn_addtocart3.Visible = true;
        }

        private void defaultenabled()
        {
            pb_others.Image = null;
            tb_itemname.Enabled = false;
            tb_itemprice.Enabled = false;
            btn_addtocart.Enabled = false;
            tb_itemname.Clear();
            tb_itemprice.Clear();
        }
        private void tShirtsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            defaultpbox();
            panel_tshirt.Visible = true;
            panel_tshirt.BringToFront();
            defaultvisible();
            lb_nama1.Text = "T-Shirt Kerah Bulat";
            lb_nama2.Text = "T-Shirt Kerah Kotak";
            lb_nama3.Text = "T-Shirt Kerah V";
            hargaproduk1 = 120000;
            hargaproduk2 = 135000;
            hargaproduk3 = 130000;
            lb_harga1.Text = $"Rp. {hargaproduk1.ToString("#,0.")}.-";
            lb_harga2.Text = $"Rp. {hargaproduk2.ToString("#,0.")}.-";
            lb_harga3.Text = $"Rp. {hargaproduk3.ToString("#,0.")}.-";
        }

        private void shirtsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            defaultpbox();
            panel_shirt.Visible = true;
            defaultvisible();
            lb_nama1.Text = "Shirt Polo";
            lb_nama2.Text = "Shirt Rumah";
            lb_nama3.Text = "Shirt White";
            hargaproduk1 = 160000;
            hargaproduk2 = 125000;
            hargaproduk3 = 120000;
            lb_harga1.Text = $"Rp. {hargaproduk1.ToString("#,0.")}.-";
            lb_harga2.Text = $"Rp. {hargaproduk2.ToString("#,0.")}.-";
            lb_harga3.Text = $"Rp. {hargaproduk3.ToString("#,0.")}.-";
        }

        private void longPantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            defaultpbox();
            panel_longpants.Visible = true;
            defaultvisible();
            lb_nama1.Text = "Long Pants High Waist";
            lb_nama2.Text = "Long Pants Jogging";
            lb_nama3.Text = "Long Pants Legging";
            hargaproduk1 = 180000;
            hargaproduk2 = 175000;
            hargaproduk3 = 160000;
            lb_harga1.Text = $"Rp. {hargaproduk1.ToString("#,0.")}.-";
            lb_harga2.Text = $"Rp. {hargaproduk2.ToString("#,0.")}.-";
            lb_harga3.Text = $"Rp. {hargaproduk3.ToString("#,0.")}.-";
        }

        private void pantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            defaultpbox();
            panel_pants.Visible = true;
            defaultvisible();
            lb_nama1.Text = "Pants Jeans";
            lb_nama2.Text = "Pants Running";
            lb_nama3.Text = "Pants Short";
            hargaproduk1 = 130000;
            hargaproduk2 = 155000;
            hargaproduk3 = 150000;
            lb_harga1.Text = $"Rp. {hargaproduk1.ToString("#,0.")}.-";
            lb_harga2.Text = $"Rp. {hargaproduk2.ToString("#,0.")}.-";
            lb_harga3.Text = $"Rp. {hargaproduk3.ToString("#,0.")}.-";
        }

        private void shoesToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            defaultpbox();
            panel_shoes.Visible = true;
            defaultvisible();
            lb_nama1.Text = "Shoes Adidas";
            lb_nama2.Text = "Shoes Nike";
            lb_nama3.Text = "Shoes Puma";
            hargaproduk1 = 110000;
            hargaproduk2 = 125000;
            hargaproduk3 = 140000;
            
            lb_harga1.Text = $"Rp. {hargaproduk1.ToString("#,0.")}.-";
            lb_harga2.Text = $"Rp. {hargaproduk2.ToString("#,0.")}.-";
            lb_harga3.Text = $"Rp. {hargaproduk3.ToString("#,0.")}.-";
        }

        private void jewelleriesToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            defaultpbox();
            panel_jewelleries.Visible = true;
            defaultvisible();
            lb_nama1.Text = "Jewelleries Bracelet";
            lb_nama2.Text = "Jewelleries Necklace";
            lb_nama3.Text = "Jewelleries Ring";
            hargaproduk1 = 160000;
            hargaproduk2 = 145000;
            hargaproduk3 = 140000;
           
            lb_harga1.Text = $"Rp. {hargaproduk1.ToString("#,0.")}.-";
            lb_harga2.Text = $"Rp. {hargaproduk2.ToString("#,0.")}.-";
            lb_harga3.Text = $"Rp. {hargaproduk3.ToString("#,0.")}.-";
        }

        private void othersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            defaultenabled();
            defaultpbox();
            panel_others.Visible = true;

            lb_nama1.Visible = false;
            lb_nama2.Visible = false;
            lb_nama3.Visible = false;

            lb_harga1.Visible = false;
            lb_harga2.Visible = false;
            lb_harga3.Visible = false;

            btn_addtocart1.Visible = false;
            btn_addtocart2.Visible = false;
            btn_addtocart3.Visible = false;
        }

        private void btn_upload_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "All Files (*.jpeg)|*.jpeg";
            ofd.ShowDialog();
            ofd.Multiselect = true;

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                pb_others.Image = Image.FromFile(ofd.FileName);
                tb_itemname.Enabled = true;
                tb_itemprice.Enabled = true;
            }
        }

        private void tb_itemprice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }


        private void cek()
        {
            if (!string.IsNullOrWhiteSpace(tb_itemname.Text) && !string.IsNullOrWhiteSpace(tb_itemprice.Text))
            {
                btn_addtocart.Enabled = true;
            }
            else
            {
                btn_addtocart.Enabled = false;
            }
        }

        private void tb_itemname_TextChanged(object sender, EventArgs e)
        {
            cek();
        }

        private void tb_itemprice_TextChanged(object sender, EventArgs e)
        {
            cek();
        }

        private void btn_addtocart_Click(object sender, EventArgs e)
        {
            addproduct(tb_itemname.Text, Convert.ToInt32(tb_itemprice.Text));
       
        }

        private void addproduct(string labelprod, int price)
        {
            dgv1.DataSource = shop;
            int quant;
            bool masuk = false;
            for (int i = 0; i < shop.Rows.Count; i++)
            {
                if (shop.Rows[i]["Item Name"].ToString() == labelprod)
                {
                    quant = Convert.ToInt32(shop.Rows[i]["Quantity"]) + 1;
                    shop.Rows[i]["Quantity"] = quant;
                    shop.Rows[i]["Total"] = quant * price;

                    masuk = true;
                    break;
                }
            }

            if (masuk == false)
            {
                shop.Rows.Add(labelprod, 1, price, price);
            }

            int subtotal = 0;
            for(int i =0; i < shop.Rows.Count; i++)
            {
                subtotal += Convert.ToInt32(shop.Rows[i]["Total"]);
            }
            tb_subtotal.Text = $"Rp. { subtotal.ToString("#,0.")}";
            double total = subtotal + subtotal * 0.1;
            tb_total.Text = $"Rp. {total.ToString("#,0.")}";
        }

        private void btn_addtocart1_Click(object sender, EventArgs e)
        {
            addproduct(lb_nama1.Text, hargaproduk1);      
        }

        private void btn_addtocart2_Click(object sender, EventArgs e)
        {
            addproduct(lb_nama2.Text, hargaproduk2);  
        }

        private void btn_addtocart3_Click(object sender, EventArgs e)
        {
            addproduct(lb_nama3.Text, hargaproduk3);
        }

        private void btn_deletecart_Click(object sender, EventArgs e)
        {
            if (baris >= 0 & shop.Rows.Count > 0)
            {
                shop.Rows.RemoveAt(baris);
                dgv1.DataSource = shop;

                int subTotal = 0;
                for (int i = 0; i < shop.Rows.Count; i++)
                {
                    subTotal += Convert.ToInt32(shop.Rows[i]["Total"]);
                }
                tb_subtotal.Text = "Rp. " + subTotal.ToString("#,0.") + ".";

                double total = subTotal + subTotal * 0.1;
                tb_total.Text = "Rp. " + total.ToString("#,0.") + ".";
            }
        }

        private void dgv1_Click(object sender, EventArgs e)
        {
            DataGridViewRow currentRow = dgv1.CurrentRow;
            tampung = currentRow.Cells[0].Value.ToString();
        }
    }
}
